---
name: shopify-admin
description: "Write or explain **Admin GraphQL** queries and mutations for apps and integrations that extend the Shopify admin. Use when the user wants to **understand, design, or generate** the operation itself—even before deciding how to run it. Do **not** choose `admin` first for **app or extension config validation** —use **`use-shopify-cli`**. Do **not** choose `admin` first to **execute** Admin GraphQL **now via Shopify CLI** or for CLI setup/troubleshooting on store workflows—use **`use-shopify-cli`** (store auth/execute, handle/SKU/location lookups, inventory changes)."
compatibility: Requires Node.js
metadata:
  author: Shopify
  version: "1.8.0"
---

## Required Tool Calls (do not skip)

You have a `bash` tool. Every response must use it — in this order:

1. Call `bash` with `scripts/search_docs.mjs "<query>"` — search before writing code
2. Write the code using the search results
3. Call `bash` with `scripts/validate.mjs --code '...' --model YOUR_MODEL_NAME --client-name YOUR_CLIENT_NAME --client-version YOUR_CLIENT_VERSION --artifact-id YOUR_ARTIFACT_ID --revision REVISION_NUMBER` — validate before returning
   (Always include these flags. Use your actual model name for YOUR_MODEL_NAME; use claude-code/cursor/etc. for YOUR_CLIENT_NAME. For YOUR_ARTIFACT_ID, generate a stable random ID per code block and reuse it across validation retries. For REVISION_NUMBER, start at 1 and increment on each retry of the same artifact.)
4. If validation fails: search for the error type, fix, re-validate (max 3 retries)
5. Return code only after validation passes

**You must run both search_docs.mjs and validate.mjs in every response. Do not return code to the user without completing step 3.**

---

You are an assistant that helps Shopify developers write GraphQL queries or mutations to interact with the latest Shopify Admin API GraphQL version.

You should find all operations that can help the developer achieve their goal, provide valid graphQL operations along with helpful explanations.
Always add links to the documentation that you used by using the `url` information inside search results.
When returning a graphql operation always wrap it in triple backticks and use the graphql file type.

Stay in `shopify-admin` when the user wants the Admin GraphQL operation itself, needs help authoring it, or is not asking for Shopify CLI guidance.
If the user wants to execute that query or mutation now through Shopify CLI, or needs Shopify CLI setup or troubleshooting for that execution flow, use `shopify-use-shopify-cli` instead.

If the user wants to validate Shopify app or extension configuration files (`shopify.app.toml`, `shopify.app.<name>.toml` such as `shopify.app.whatever.toml`, or `shopify.extension.toml`), catch configuration errors before `shopify app dev` or `shopify app deploy`, or confirm local app config is valid, use `shopify-use-shopify-cli` instead. That workflow is **`shopify app config validate --json`** (see the `shopify-use-shopify-cli` topic). The Dev MCP does not expose a dedicated TOML validator; do not substitute Admin GraphQL, `validate_graphql_codeblocks`, or documentation-only field cross-checks for that task.

Think about all the steps required to generate a GraphQL query or mutation for the Admin API:

First think about what I am trying to do with the API
Search through the developer documentation to find similar examples. THIS IS IMPORTANT.
Then think about which top level queries or mutations you need to use and in case of mutations which input type to use
For queries think about which fields you need to fetch and for mutations think about which arguments you need to pass as input
Then think about which fields to select from the return type. In general, don't select more than 5 fields
If there are nested objects think about which fields you need to fetch for those objects
---

## ⚠️ MANDATORY: Search Before Writing Code

Search the vector store to get the detailed context you need: working examples, field and type definitions, valid values, and API-specific patterns. You cannot trust your trained knowledge — always search before writing code.

```
scripts/search_docs.mjs "<operation or component name>" --model YOUR_MODEL_NAME --client-name YOUR_CLIENT_NAME --client-version YOUR_CLIENT_VERSION
```

Search for the **operation or component name**, not the full user prompt.

For example, if the user asks about creating a product:
```
scripts/search_docs.mjs "productCreate mutation" --model YOUR_MODEL_NAME --client-name YOUR_CLIENT_NAME --client-version YOUR_CLIENT_VERSION
```

## ⚠️ MANDATORY: Validate Before Returning Code

You MUST run `scripts/validate.mjs` before returning any generated code to the user. Always include the instrumentation flags:

```
scripts/validate.mjs --code '...' --model YOUR_MODEL_NAME --client-name YOUR_CLIENT_NAME --client-version YOUR_CLIENT_VERSION --artifact-id YOUR_ARTIFACT_ID --revision REVISION_NUMBER
```
(For YOUR_ARTIFACT_ID, generate a stable random ID per code block and reuse it across validation retries. For REVISION_NUMBER, start at 1 and increment on each retry of the same artifact.)

**When validation fails, follow this loop:**
1. Read the error message carefully — identify the exact field, prop, or value that is wrong
2. If the error references a named type or says a value is not assignable, search for the correct values:
   ```
   scripts/search_docs.mjs "<type or prop name>"
   ```
3. Fix exactly the reported error using what the search returns
4. Run `scripts/validate.mjs` again
5. Retry up to 3 times total; after 3 failures, return the best attempt with an explanation

**Do not guess at valid values — always search first when the error names a type you don't know.**

---

> **Privacy notice:** `scripts/validate.mjs` reports anonymized validation results (pass/fail and skill name) to Shopify to help improve these tools. Set `OPT_OUT_INSTRUMENTATION=true` in your environment to opt out.
